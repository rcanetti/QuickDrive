import sys
import socket
import pickle
from aes import *
from rsa import *

aes_key = 'Shalev'
AESC = AESCipher(aes_key)

print("client start")
my_socket = socket.socket()
my_socket.connect(("127.0.0.1",8820))
print("client connect to server")

# Step 1
my_socket.send('ClientHello'.encode('utf-8'))

# Step 2
server_hello = my_socket.recv(1024).decode()
pubKey = my_socket.recv(1024)

# Step 4
my_socket.send(encrypt(RSA.import_key(pubKey), aes_key))

# Step 5
my_socket.send(AESC.encrypt('Finished').encode('utf-8'))

# Step 6
server_finished = my_socket.recv(1024).decode('utf-8')

while (1):
    val = input("Menu\n 1. Name\n 2. Rand\n 3. Time\n 4. Quit for exit:\n")
    if val == "Quit":
        my_socket.shutdown(socket.SHUT_RDWR)
        my_socket.close()
        sys.exit()
    val = AESC.encrypt(val)
    my_socket.send(val.encode('utf-8'))
    enc_data = my_socket.recv(1024).decode('utf-8')
    data = AESC.decrypt(enc_data)
    print(f'encrypted: {val}, {enc_data}\ndecrypted: {AESC.decrypt(val)}, {data}')