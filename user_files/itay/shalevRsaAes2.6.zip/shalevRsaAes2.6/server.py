import socket
import sys
import random
import time
from aes import *
from rsa import *

print("server start")
server_socket = socket.socket()
server_socket.bind(('0.0.0.0',8820))

server_socket.listen(1)

(client_socket, client_address) = server_socket.accept()
print("client was connecting")

pubKey, priKey = get_keys(1024)

# Step 1
client_hello = client_socket.recv(1024).decode('utf-8')

# Step 2
client_socket.send('ServerHello'.encode('utf-8'))
client_socket.send(pubKey.export_key())

# Step 4
enc_aes_key = client_socket.recv(1024)
aes_key = decrypt(priKey, enc_aes_key).decode('utf-8')
AESC = AESCipher(aes_key)

# Step 5
client_finished = client_socket.recv(1024).decode('utf-8')

# Step 6
client_socket.send(AESC.encrypt('Finished').encode('utf-8'))

while(1):
    client_info = client_socket.recv(1024)
    client_info_str = AESC.decrypt(client_info.decode('utf-8')) #convert the bytes to string
    if client_info_str == "":
        client_socket.close()
        server_socket.close()
        print ("client close the socket")
        sys.exit()
    print ("server got: " + client_info_str)
    if client_info_str == "Name":
        data = "Yosi"
    elif client_info_str == "Rand":
        number = random.randint(1,11)
        data = str(number)
    elif client_info_str == "Time":
        data = time.ctime()
    elif client_info_str.startswith('get_key,'):
        key = client_info_str.removeprefix('get_key,')
        print(key)
        data = '12345'
    else: 
        data = client_info_str #reverse the string
    data = AESC.encrypt(data)
    data = data.encode('utf-8') #convert the string to bytes
    client_socket.send(data)
